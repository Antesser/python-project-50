#!/usr/bin/env python
from gendiff.entering_point import entering_point


def main():
    entering_point()


if __name__ == '__main__':
    main()
