#!/usr/bin/env python
from gendiff.cli import run


def main():
    run()


if __name__ == '__main__':
    main()
